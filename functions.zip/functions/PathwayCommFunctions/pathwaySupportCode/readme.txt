Pathway Network Interface Demo

Instructions for use:
1. Add the content of the folder Pathway Network Interface Demo, including sub folders to Matlab Path
2. Type in command Window: main(hostName, portNum, commandId, parameter) and specify host name, port number, command Id and parameter if required.
3. The response will be displayed in the command windows.
4. for more help, see comments inside functions.

Written by Yael Frankel
code for client.m was adapted from code by Rodney Thomson, available on Matlab file exchange:
http://www.mathworks.com/matlabcentral/fileexchange/25249-tcp-ip-socket-communications-in-matlab-using-java-classes
code for converting date and time to unix format written by Arvind Pereira

 





